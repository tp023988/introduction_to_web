function currency(selectedCurrency)
{
  let kzt = document.querySelector("#KZT").value;
  var result = 0;
  if(selectedCurrency === "USD")
  {
    result = kzt/380;
  }
  if(selectedCurrency === "EURO")
  {
    result = kzt/420;
  }
  document.querySelector("#result").value = result.toFixed(2);
}
