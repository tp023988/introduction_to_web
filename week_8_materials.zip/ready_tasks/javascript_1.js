function toEnglish()
{
  document.querySelector("#lang_id").innerHTML = "English";
  document.querySelector("#h1_id").innerHTML = "Site Header";
  document.querySelector("#nav_id").innerHTML = "Navigation";
  document.querySelector("#p1_id").innerHTML = "Description 1";
  document.querySelector("#p2_id").innerHTML = "Description 2";
  document.querySelector("#aside_id").innerHTML = "Sidebar";
  document.querySelector("#footer_id").innerHTML = "Footer";
}

function toRussian()
{
  document.querySelector("#lang_id").innerHTML = "Русский";
  document.querySelector("#h1_id").innerHTML = "Заголовок сайта";
  document.querySelector("#nav_id").innerHTML = "Навигация";
  document.querySelector("#p1_id").innerHTML = "Описание 1";
  document.querySelector("#p2_id").innerHTML = "Описание 2";
  document.querySelector("#aside_id").innerHTML = "Сайдбар";
  document.querySelector("#footer_id").innerHTML = "Подвал сайта";
}
