var counter = 0;
function checkSubmit()
{
  if(counter<3)
  {
    var login = document.querySelector("#login_id").value
    var password = document.querySelector("#password_id").value
    console.log('login:'+login)
    if(
        (login.length>5)
      &&
        (
          (login.includes("@") && login.includes("."))
          ||
          (login.includes("+7"))
        )
      )
    {
      //check for a variable
      var theUrl = "https://raw.githubusercontent.com/tp023988/IT-1916/master/online_variable";
      var xmlHttp = new XMLHttpRequest();
      xmlHttp.open( "GET", theUrl, false ); // false for synchronous request
      xmlHttp.send( null );
      var responseVar = xmlHttp.responseText;
      console.log("the password text:"+password)
      console.log("the response text:"+responseVar)
      console.log(password.localeCompare(responseVar))
      if(password.localeCompare(responseVar) == 0 )
      {
          console.log("password:"+password)
          alert('nice, your password is correct');
      }
      return false;
    }
    else
    {
      alert("Attention! You are entering the wrong data!");
      counter = counter+1;
      return false;
    }
  }
  else
  {
    alert("sorry! you are suspected to be a robot!");
    return false;
  }

}
